<!-- Footer Start -->
<footer class="footer">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-6">
                          2021 &copy; CDA Campus Pvt. Ltd
 <a href="#"></a>
                        </div>
                        
                    </div>
                </div>
            </footer>
            <!-- end Footer -->