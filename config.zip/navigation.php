<div class="left-side-menu">

    <div class="slimscroll-menu">


        <div id="sidebar-menu">

            <ul class="metismenu" id="side-menu">

                <li class="menu-title">Navigation</li>

                <li>
                    <a href="index.php">
                        <i class="fe-airplay"></i>

                        <span> Home </span>
                    </a>

                </li>
                <li>
                    <a href="#">
                        <i class="fe-package"></i>
                        <span class="menu-arrow"></span>
                        <span>Add Cources</span>
                        <ul class="nav-second-level" aria-expanded="false">
                                    <li>
                                        <a href="cources.php">Add</a>
                                    </li>
                                    <li>
                                        <a href="cources_view.php">View</a>
                                    </li>
</ul>
                    </a>

                </li>


                <li>
                    <a href="#">
                        <i class="fe-package"></i>
                        <span class="menu-arrow"></span>
                        <span> Test Series </span>
                        <ul class="nav-second-level" aria-expanded="false">
                                    <li>
                                        <a href="testseries.php">Add</a>
                                    </li>
                                    <li>
                                        <a href="testseries_view.php">View</a>
                                    </li>
</ul>
                    </a>

                </li>
               




                <li>
                    <a href="#">
                        <i class="fe-pocket"></i>
                        <span class="menu-arrow"></span>
                        <span>Upcoming Batches </span>
                        <ul class="nav-second-level" aria-expanded="false">
                                    <li>
                                        <a href="upcomingbatch.php">Add</a>
                                    </li>
                                    <li>
                                        <a href="upcomingbatch_view.php">View</a>
                                    </li>
</ul>

                    </a>

                </li>
                <li>
                    <a href="#">
                        <i class="fe-shopping-cart"></i>
                        <span class="menu-arrow"></span>
                        <span>Photo Gallery  </span>
                        <ul class="nav-second-level" aria-expanded="false">
                                    <li>
                                        <a href="photogallery.php">Add</a>
                                    </li>
                                    <li>
                                        <a href="photogallery_view.php">View</a>
                                    </li>
</ul>
                    </a>

                </li>

                <li>
                    <a href="#">
                        <i class="fe-users"></i>
                        <span class="menu-arrow"></span>
                        <span> News Update </span>
                        <ul class="nav-second-level" aria-expanded="false">
                                    <li>
                                        <a href="news.php">Add</a>
                                    </li>
                                    <li>
                                        <a href="news_view.php">View</a>
                                    </li>
</ul>
                    </a>

                </li>

                

                <li>
                    <a href="#">
                        <i class="fe-sidebar"></i>
                        <span class="menu-arrow"></span>

                        <span> Success Story </span>
                        <ul class="nav-second-level" aria-expanded="false">
                                    <li>
                                        <a href="successstory.php">Add</a>
                                    </li>
                                    <li>
                                        <a href="successstory_view.php">View</a>
                                    </li>
</ul> </a>

                </li>

                <li>
                    <a href="#">
                        <i class="fe-mail"></i>
                        
                        <span class="menu-arrow"></span>
                        <span>Selected Students </span>
                        <ul class="nav-second-level" aria-expanded="false">
                                    <li>
                                        <a href="selectedstudent.php">Add</a>
                                    </li>
                                    <li>
                                        <a href="selectedstudent_view.php">View</a>
                                    </li>
</ul>
                    </a>

                </li>
                <li>
                    <a href="query.php">
                        <i class="fe-package"></i>
                        <span> Query </span>

                    </a>

                </li>
                <li>
                    <a href="feedback.php">
                        <i class="fe-mail"></i>
                        <span>Feedback</span>

                    </a>

                </li>


                <li>
                    <a href="contact.php">
                        <i class="fe-mail"></i>
                        <span>Contact Us</span>

                    </a>

                </li>


                </li>
                
                <li>
                    <a href="#">
                        <i class="fe-mail"></i>
                        
                        <span class="menu-arrow"></span>
                        <span>Live Classes </span>
                        <ul class="nav-second-level" aria-expanded="false">
                                    <li>
                                        <a href="selectedstudent.php">Add</a>
                                    </li>
                                    <li>
                                        <a href="selectedstudent_view.php">View</a>
                                    </li>
</ul>
                    </a>

                </li>
                <li>
                    <a href="#">
                        <i class="fe-mail"></i>
                        
                        <span class="menu-arrow"></span>
                        <span>Upload Videos </span>
                        <ul class="nav-second-level" aria-expanded="false">
                                    <li>
                                        <a href="selectedstudent.php">Add</a>
                                    </li>
                                    <li>
                                        <a href="selectedstudent_view.php">View</a>
                                    </li>
</ul>
                    </a>

                </li>


                

               

            </ul>

        </div>
        <!-- End Sidebar -->

        <div class="clearfix"></div>

    </div>
    <!-- Sidebar -left -->

</div>